from django.apps import AppConfig

class ServicesConfig(AppConfig):  # NEW
    default_auto_field = "django.db.models.BigAutoField"
    name = "services"
