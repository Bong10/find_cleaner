from rest_framework import serializers
from django.contrib.auth import get_user_model
from .models import Cleaner, Role, User, Admin, Employer
from phonenumber_field.serializerfields import PhoneNumberField
from django.core.mail import send_mail
from datetime import timedelta
from django.utils import timezone



User = get_user_model()

class UserCreateSerializer(serializers.Serializer):
    def validate(self, attrs):
        print("🚨 BlockedRegistrationSerializer activated")
        raise serializers.ValidationError("🚫 Registration is disabled by the administrator.")
    

class CustomUserSerializer(serializers.ModelSerializer):
    role = serializers.SerializerMethodField(read_only=True)  # Return role name
    role_id = serializers.PrimaryKeyRelatedField(
        source='role',
        queryset=Role.objects.all(),
        write_only=True,
        required=False
    )  # Allow role to be set by ID

    class Meta:
        model = User
        fields = [
            'id',
            'email',
            'phone_number',
            'name',
            'gender',
            'profile_picture',
            'address',
            'password',
            'role',      # Exposed as role name
            'role_id',   # Used for input
        ]
        extra_kwargs = {
            'password': {'write_only': True}
        }

    def get_role(self, obj):
        return obj.role.name if obj.role else None

    def create(self, validated_data):
        user = User.objects.create_user(**validated_data)
        return user


class CleanerRegistrationSerializer(serializers.ModelSerializer):
    user = CustomUserSerializer()

    class Meta:
        model = Cleaner
        fields = ['user', 'portfolio', 'years_of_experience', 'dbs_check', 'insurance_details', 'availibility_status', 'clean_level','id']

    def create(self, validated_data):
        user_data = validated_data.pop('user')
        role = Role.objects.get(name="cleaner")
        user = User.objects.create_user(**user_data)  
        user.role = role
        user.is_active = False  
        user.save()

        # Création du cleaner
        cleaner = Cleaner.objects.create(user=user, **validated_data)


        return cleaner



class EmployerRegistrationSerializer(serializers.ModelSerializer):
    user = CustomUserSerializer()  # Utilise le sérialiseur CustomUserSerializer

    class Meta:
        model = Employer
        fields = ['user', 'business_name', 'location','id']

    def create(self, validated_data):
        user_data = validated_data.pop('user')

        # Vérification si le rôle existe
        try:
            role = Role.objects.get(name="employer")
        except Role.DoesNotExist:
            raise serializers.ValidationError("Le rôle 'employer' n'existe pas.")

        # Création de l'utilisateur
        user = User.objects.create_user(**user_data)

        # Assignation du rôle à l'utilisateur
        user.role = role
        user.save()

        # Création du livreur
        employer = Employer.objects.create(
            user=user,
            **validated_data  # Utilisation des données validées
        )

       
        user.save()

        return employer
    
class AdminRegistrationSerializer(serializers.ModelSerializer):
    user = CustomUserSerializer()

    class Meta:
        model = Admin
        fields = ['user']

    def create(self, validated_data):
        user_data = validated_data.pop('user')
        # Le rôle "Admin" est affecté automatiquement ici.
        role = Role.objects.get(name="admin")
        user = User.objects.create_user(**user_data)
        user.role = role
        user.save()
        admin = Admin.objects.create(user=user)
        user.save()
        return admin



class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = ['id', 'name']
        extra_kwargs = {
            'name': {'required': True, 'allow_blank': False},
        }

    def create(self, validated_data):
        """
        Crée un rôle après avoir validé les données.
        """
        return Role.objects.create(**validated_data)

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'phone', 'email', 'name', 'address', 'gender','profile_picture','is_active']



