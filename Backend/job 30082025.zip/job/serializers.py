# job/serializers.py
from rest_framework import serializers

from .models import (
    Job, Service, JobApplication, JobBooking, JobService, CleanerService, Shortlist
)


# ---------------------------
# Services
# ---------------------------

class ServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Service
        fields = ["id", "name", "price", "duration"]


class JobServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = JobService
        fields = ["job_service_id", "job", "service"]


class CleanerServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = CleanerService
        fields = ["cleaner_service_id", "cleaner", "service"]


# ---------------------------
# Job
# ---------------------------

class JobCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Job
        # CHANGED: align to model (hourly_rate + hours_required; date/time; no budget/start/end)
        fields = [
            "job_id",                # read-only PK
            "title",
            "description",
            "location",
            "date",                  # NEW (from model)
            "time",                  # NEW (from model)
            "hourly_rate",           # NEW (replaces budget)
            "hours_required",        # NEW
            "special_requirements",  # CHANGED: TextField on model
            "status",                # read-only on create (set in view to "o")
            "employer",              # read-only (injected in view)
        ]
        read_only_fields = ["job_id", "status", "employer"]


class JobListSerializer(serializers.ModelSerializer):
    employer_name = serializers.CharField(source="employer.user.name", read_only=True)
    estimated_total = serializers.SerializerMethodField(read_only=True)  # NEW

    class Meta:
        model = Job
        # CHANGED: align to model, include computed total
        fields = [
            "job_id",
            "title",
            "location",
            "date",
            "time",
            "hourly_rate",
            "hours_required",
            "estimated_total",   # NEW
            "status",
            "created_at",
            "employer_name",
        ]

    def get_estimated_total(self, obj):  # NEW
        try:
            return float(obj.hourly_rate) * float(obj.hours_required)
        except Exception:
            return 0.0


class JobDetailSerializer(serializers.ModelSerializer):
    employer_name = serializers.CharField(source="employer.user.name", read_only=True)
    estimated_total = serializers.SerializerMethodField(read_only=True)  # NEW
    services = ServiceSerializer(many=True, read_only=True)  # NEW (through M2M)

    class Meta:
        model = Job
        # CHANGED: align to model, remove non-existent fields, add services + computed total
        fields = [
            "job_id",
            "title",
            "description",
            "location",
            "date",
            "time",
            "hourly_rate",
            "hours_required",
            "estimated_total",       # NEW
            "special_requirements",
            "status",
            "created_at",
            "employer_name",
            "services",              # NEW
        ]

    def get_estimated_total(self, obj):  # NEW
        try:
            return float(obj.hourly_rate) * float(obj.hours_required)
        except Exception:
            return 0.0


# ---------------------------
# Applications
# ---------------------------

class JobApplicationCreateSerializer(serializers.ModelSerializer):
    """
    Cleaner applies to a job. Cleaner is injected from request.user in create().
    """
    class Meta:
        model = JobApplication
        # CHANGED: date_applied (model), not created_at
        fields = ["application_id", "job", "cleaner", "cover_letter", "status", "date_applied"]
        read_only_fields = ["application_id", "cleaner", "status", "date_applied"]

    def validate(self, attrs):  # NEW: basic guarding
        job = attrs.get("job")
        if job and job.status != "o":
            raise serializers.ValidationError("You can only apply to open jobs.")
        return attrs

    def create(self, validated_data):
        request = self.context.get("request")
        if not request or not hasattr(request.user, "cleaner"):
            raise serializers.ValidationError("Only cleaners can apply to a job.")

        cleaner = request.user.cleaner

        # Prevent duplicate applications (matches model unique_together)
        if JobApplication.objects.filter(job=validated_data["job"], cleaner=cleaner).exists():
            raise serializers.ValidationError("You have already applied to this job.")

        validated_data["cleaner"] = cleaner
        validated_data["status"] = "p"  # ensure pending on create
        return super().create(validated_data)


class JobApplicationListSerializer(serializers.ModelSerializer):
    job_title = serializers.CharField(source="job.title", read_only=True)
    cleaner_name = serializers.CharField(source="cleaner.user.name", read_only=True)

    class Meta:
        model = JobApplication
        # CHANGED: date_applied (model), not created_at
        fields = [
            "application_id",
            "job",
            "job_title",
            "cleaner",
            "cleaner_name",
            "cover_letter",
            "status",
            "date_applied",
        ]


# ---------------------------
# Shortlist
# ---------------------------

class ShortlistCreateSerializer(serializers.ModelSerializer):
    shortlist_id = serializers.IntegerField(source="id", read_only=True)  # NEW: keep API stable

    class Meta:
        model = Shortlist
        # CHANGED: model has default PK `id`; expose as shortlist_id for compatibility
        fields = ["shortlist_id", "job", "cleaner"]


class ShortlistListSerializer(serializers.ModelSerializer):
    shortlist_id = serializers.IntegerField(source="id", read_only=True)  # NEW
    job_title = serializers.CharField(source="job.title", read_only=True)
    cleaner_name = serializers.CharField(source="cleaner.user.name", read_only=True)

    class Meta:
        model = Shortlist
        # CHANGED: removed non-existent created_at, expose shortlist_id
        fields = [
            "shortlist_id",
            "job",
            "job_title",
            "cleaner",
            "cleaner_name",
        ]


# ---------------------------
# Booking
# ---------------------------

class JobBookingSerializer(serializers.ModelSerializer):
    job_booking_id = serializers.IntegerField(source="booking_id", read_only=True)  # NEW: keep API stable
    job_title = serializers.CharField(source="job.title", read_only=True)
    cleaner_name = serializers.CharField(source="cleaner.user.name", read_only=True)

    class Meta:
        model = JobBooking
        # CHANGED: model PK is booking_id; expose job_booking_id for compatibility
        fields = [
            "job_booking_id",
            "job",
            "job_title",
            "cleaner",
            "cleaner_name",
            "payment",
            "status",
        ]
