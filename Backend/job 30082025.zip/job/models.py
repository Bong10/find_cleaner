from django.db import models
from django.shortcuts import get_object_or_404
from django.core.validators import MinValueValidator  # NEW
from users.models import Employer, Cleaner, User


class Payment(models.Model):
    # models payment pour les test
    name = models.CharField(max_length=100)


class Service(models.Model):
    """
    Represents cleaning services offered on the platform.
    """
    name = models.CharField(max_length=100, default="my service name")
    price = models.FloatField(default=0.0)
    duration = models.CharField(max_length=50, default="one week")

    def __str__(self):
        return f" {self.name} $({self.price}) "


class Job(models.Model):
    """
    Represents a cleaning task posted by employers
    """

    STATUS_CHOICES = [
        ("o", "Open"),
        ("p", "Pending"),       # awaiting action
        ("t", "Taken"),         # booked/assigned
        ("ip", "In progress"),
        ("c", "Completed"),
    ]

    job_id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=100, default="My Job title ")
    description = models.TextField(default="No Description")
    employer = models.ForeignKey(Employer, on_delete=models.CASCADE)
    location = models.CharField(max_length=50)
    date = models.DateField()
    time = models.CharField(max_length=10)
    status = models.CharField(max_length=2, choices=STATUS_CHOICES, default="o")  # CHANGED (added default)

    # CHANGED: replace flat budget with hourly model
    hourly_rate = models.DecimalField(  # NEW
        max_digits=10, decimal_places=2, validators=[MinValueValidator(0)]
    )
    hours_required = models.DecimalField(  # NEW (supports fractional hours like 1.5)
        max_digits=6, decimal_places=2, validators=[MinValueValidator(0.25)]
    )

    special_requirements = models.TextField(blank=True, default="")  # CHANGED (CharField -> TextField with sensible defaults)

    services = models.ManyToManyField(Service, related_name="jobs", through='JobService')
    created_at = models.DateTimeField(auto_now_add=True)

    # REMOVED: budget (replaced by hourly_rate + hours_required)

    shorlist = models.ManyToManyField(Cleaner, related_name="shorted_jobs", through="Shortlist")

    def __str__(self):
        return f"Job {self.job_id} posted by {self.employer_id}"

    class Meta:
        ordering = ['-created_at']

    # Convenience total (not stored)
    @property
    def estimated_total(self):  # NEW
        try:
            return (self.hourly_rate or 0) * (self.hours_required or 0)
        except Exception:
            return 0

    def assignCleaner(self, cleaner_id: int):
        """ Assigns a cleaner to the job. """
        cleaner = Cleaner.objects.get(pk=cleaner_id)
        if cleaner:
            book = JobBooking.objects.create(
                job=self,             # FIXED: was "Job=self"
                cleaner=cleaner,
                status="cf",
            )
            if book:
                self.status = 't'
                self.save()
                return True
        return False

    def updateStatus(self, new_status: str):
        """ Updates the job’s status. """
        self.status = new_status
        self.save()

    @property
    def markAsComplete(self):
        """ Marks the job as completed."""
        if self.status != 'c':
            self.status = 'c'
            self.save()
            return True
        return False


class Shortlist(models.Model):
    cleaner = models.ForeignKey(Cleaner, on_delete=models.CASCADE)
    job = models.ForeignKey(Job, on_delete=models.CASCADE)


class JobService(models.Model):
    """
    Tracks services associated with specific jobs.
    """
    job_service_id = models.AutoField(primary_key=True)
    job = models.ForeignKey(Job, on_delete=models.CASCADE)
    service = models.ForeignKey(Service, on_delete=models.CASCADE)

    @staticmethod
    def addServiceToJob(job_id: int, service_id: int):
        job = get_object_or_404(Job, pk=job_id)
        service = get_object_or_404(Service, pk=service_id)
        if JobService.objects.create(job=job, service=service):
            return True
        return False

    @staticmethod
    def removeServiceFromJob(job_service_id: int):
        if JobService.objects.get(pk=job_service_id).delete():
            return True
        return False


class JobApplication(models.Model):
    """
    Tracks applications submitted by cleaners for jobs.
    """
    STATUS_CHOICES = [
        ("p", "Pending"),
        ("a", "Accepted"),
        ("r", "Rejected"),
    ]
    application_id = models.AutoField(primary_key=True)
    cleaner = models.ForeignKey(Cleaner, on_delete=models.CASCADE)
    job = models.ForeignKey(Job, on_delete=models.CASCADE)
    status = models.CharField(max_length=1, choices=STATUS_CHOICES, default="p")
    date_applied = models.DateField(auto_now_add=True)
    cover_letter = models.TextField(default="No cover letter")

    class Meta:
        unique_together = ('job', 'cleaner')

    @staticmethod
    def applyForJob(job_id: int, cleaner_id: int):
        """
        Allows a cleaner to apply for a job. Ensures that the cleaner
        cannot apply twice for the same job.

        Returns:
            Boolean: True if success False else.
        """
        job = Job.objects.get(pk=job_id)
        cleaner = Cleaner.objects.get(pk=cleaner_id)
        if JobApplication.objects.filter(job=job, cleaner=cleaner).exists():
            return False
        else:
            JobApplication.objects.create(job=job, cleaner=cleaner, status="p")
            return True

    @staticmethod
    def updateStatus(application_id: int, new_status: str):
        application = JobApplication.objects.get(pk=application_id)
        application.status = new_status
        application.save()


class JobBooking(models.Model):
    """
    Tracks confirmed bookings for jobs.
    """
    CHOICES = [
        ("cf", "Confirmed"),   # lorsque le cleaner accepte l'offre
        ("cp", "Completed"),   # lorsque on a payer le cleaner
        ("p", "Pending"),      # lorsque l'employer demande a réservé un cleaner
        ("r", "Rejected"),     # Si le cleaner rejecte l'offre
    ]
    booking_id = models.AutoField(primary_key=True)
    job = models.ForeignKey(Job, on_delete=models.CASCADE)
    cleaner = models.ForeignKey(Cleaner, on_delete=models.CASCADE)
    payment = models.ForeignKey("Payment", on_delete=models.CASCADE, null=True, blank=True)
    status = models.CharField(max_length=2, choices=CHOICES, default="p")

    class Meta:
        unique_together = ('job', 'cleaner')

    @staticmethod
    def confirmBooking(booking_id: int):
        """
        allow cleaner to confirm book
        """
        book = get_object_or_404(JobBooking, pk=booking_id)
        if book is not None:
            book.status = "cf"
            book.save()
            return True
        else:
            return False

    @staticmethod
    def updateBookingStatus(booking_id: int, status: str):
        """
        Enable to update JobBooking status
        """
        book = get_object_or_404(JobBooking, pk=booking_id)
        if book is not None:
            book.status = status
            book.save()
            return True
        return False


class CleanerService(models.Model):
    """
    Tracks services offered by cleaners.
    """
    cleaner_service_id = models.AutoField(primary_key=True)
    cleaner = models.ForeignKey(Cleaner, on_delete=models.CASCADE)
    service = models.ForeignKey(Service, on_delete=models.CASCADE)

    @staticmethod
    def addServiceToCleaner(service_id: int, cleaner_id: int):
        """
        Links a cleaner to a service they offer.
        """
        service = get_object_or_404(Service, pk=service_id)
        cleaner = get_object_or_404(Cleaner, pk=cleaner_id)

        if CleanerService.objects.create(service=service, cleaner=cleaner):
            return True
        return False

    @staticmethod  # NEW (it was missing @staticmethod)
    def removeServiceFromCleaner(cleaner_service_id: int):
        """
        Removes a cleaner-service link.
        """
        if CleanerService.objects.get(pk=cleaner_service_id).delete():
            return True
        return False
