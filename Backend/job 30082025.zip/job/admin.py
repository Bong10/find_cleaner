from django.contrib import admin


from .models import Service,Job,JobService,JobApplication,Shortlist

admin.site.register(Service)
admin.site.register(Job)
admin.site.register(JobService)
admin.site.register(JobApplication)
admin.site.register(Shortlist)