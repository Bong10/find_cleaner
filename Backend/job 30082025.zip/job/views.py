# job/views.py
from django.db.models import Q
from django.shortcuts import get_object_or_404
from rest_framework import viewsets, mixins, status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated, IsAdminUser, AllowAny
from rest_framework.response import Response

# ---------------------------
# Imports  (CHANGED)
# ---------------------------
from .models import (
    Job, JobApplication, Shortlist, JobBooking,
    Service, JobService, CleanerService     # <-- ADDED
)
from .serializers import (
    JobCreateUpdateSerializer, JobListSerializer, JobDetailSerializer,
    JobApplicationCreateSerializer, JobApplicationListSerializer,
    ShortlistCreateSerializer, ShortlistListSerializer, JobBookingSerializer,
    ServiceSerializer, JobServiceSerializer, CleanerServiceSerializer       # <-- ADDED
)
from .permissions import IsEmployer, IsJobOwnerOrReadOnly  # NEW
# ---------------------------


# ---------------------------
# Utilities
# ---------------------------

def get_employer_for_user(user):
    if hasattr(user, "employer"):
        return user.employer
    raise PermissionError("Only employers can perform this action.")


def get_cleaner_for_user(user):
    if hasattr(user, "cleaner"):
        return user.cleaner
    raise PermissionError("Only cleaners can perform this action.")


# ---------------------------
# Job
# ---------------------------

class JobViewSet(viewsets.ModelViewSet):
    queryset = Job.objects.all().select_related("employer")
    permission_classes = [IsAuthenticated, IsJobOwnerOrReadOnly]
    lookup_field = "job_id"

    def get_serializer_class(self):
        if self.action in ("create", "update", "partial_update"):
            return JobCreateUpdateSerializer
        if self.action == "list":
            return JobListSerializer
        return JobDetailSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        user = self.request.user

        # Employer's private list: /api/jobs?mine=true
        mine = self.request.query_params.get("mine")
        if mine == "true" and user.is_authenticated and hasattr(user, "employer"):
            return qs.filter(employer_id=user.employer.id)

        # Public list (for cleaners): only open jobs
        if self.action == "list":
            return qs.filter(status="o")
        return qs

    def perform_create(self, serializer):
        employer = get_employer_for_user(self.request.user)
        serializer.save(employer=employer, status="o")  # force new jobs to open

    def perform_update(self, serializer):
        instance = self.get_object()
        if instance.status in ("t", "ip", "c"):
            raise PermissionError("You can only edit jobs that are open.")
        serializer.save()

    def destroy(self, request, *args, **kwargs):
        job = self.get_object()
        # Guard: cannot delete if something is underway
        has_accepted = JobApplication.objects.filter(job_id=job.job_id, status="a").exists()
        has_booking = JobBooking.objects.filter(job_id=job.job_id).exclude(status="cx").exists()
        if has_accepted or has_booking:
            return Response(
                {"detail": "Cannot delete a job with accepted applications or active bookings."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        return super().destroy(request, *args, **kwargs)

    # Employer-only actions
    @action(detail=True, methods=["post"], permission_classes=[IsAuthenticated, IsJobOwnerOrReadOnly])
    def close(self, request, job_id=None):
        job = self.get_object()
        job.status = "c"
        job.save(update_fields=["status"])
        return Response({"detail": "Job closed.", "status": job.status})

    @action(detail=True, methods=["post"], permission_classes=[IsAuthenticated, IsJobOwnerOrReadOnly])
    def reopen(self, request, job_id=None):
        job = self.get_object()
        if JobApplication.objects.filter(job_id=job.job_id, status="a").exists():
            return Response({"detail": "Cannot reopen a job with an accepted application."}, status=400)
        job.status = "o"
        job.save(update_fields=["status"])
        return Response({"detail": "Job reopened.", "status": job.status})


# ---------------------------
# Applications
# ---------------------------

class JobApplicationViewSet(
    viewsets.GenericViewSet,
    mixins.CreateModelMixin,
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
):
    queryset = JobApplication.objects.all().select_related("job", "cleaner")
    permission_classes = [IsAuthenticated]
    lookup_field = "application_id"

    def get_serializer_class(self):
        return JobApplicationCreateSerializer if self.action == "create" else JobApplicationListSerializer

    def get_queryset(self):
        qs = super().get_queryset()
        user = self.request.user
        if hasattr(user, "employer"):
            # Employer sees applications to their jobs
            return qs.filter(job__employer_id=user.employer.id)
        elif hasattr(user, "cleaner"):
            # Cleaner sees their own applications
            return qs.filter(cleaner_id=user.cleaner.id)
        return qs.none()

    def perform_create(self, serializer):
        serializer.save()  # cleaner is injected in serializer.create()

    @action(detail=True, methods=["post"], permission_classes=[IsAuthenticated])
    def accept(self, request, application_id=None):
        app = self.get_object()
        user = request.user
        if not hasattr(user, "employer") or app.job.employer_id != user.employer.id:
            return Response({"detail": "Only the job owner can accept applications."}, status=403)
        if app.status != "p":
            return Response({"detail": "Only pending applications can be accepted."}, status=400)

        # Accept, set job to taken, create booking
        app.status = "a"
        app.save(update_fields=["status"])
        job = app.job
        if job.status == "o":
            job.status = "t"
            job.save(update_fields=["status"])
        JobBooking.objects.get_or_create(job=job, cleaner=app.cleaner, defaults={"status": "cf"})
        return Response({"detail": "Application accepted."})

    @action(detail=True, methods=["post"], permission_classes=[IsAuthenticated])
    def reject(self, request, application_id=None):
        app = self.get_object()
        user = request.user
        if not hasattr(user, "employer") or app.job.employer_id != user.employer.id:
            return Response({"detail": "Only the job owner can reject applications."}, status=403)
        if app.status != "p":
            return Response({"detail": "Only pending applications can be rejected."}, status=400)
        app.status = "r"
        app.save(update_fields=["status"])
        return Response({"detail": "Application rejected."})


# ---------------------------
# Shortlist
# ---------------------------

class ShortlistViewset(
    viewsets.GenericViewSet,
    mixins.CreateModelMixin,
    mixins.DestroyModelMixin,
    mixins.ListModelMixin,
):
    queryset = Shortlist.objects.all().select_related("job", "cleaner")
    permission_classes = [IsAuthenticated]
    lookup_field = "shortlist_id"

    def get_serializer_class(self):
        return ShortlistCreateSerializer if self.action == "create" else ShortlistListSerializer

    def get_queryset(self):
        user = self.request.user
        if hasattr(user, "employer"):
            return self.queryset.filter(job__employer_id=user.employer.id)
        return self.queryset.none()


# ---------------------------
# Booking (read-only for now)
# ---------------------------

class JobBookingViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = JobBooking.objects.all().select_related("job", "cleaner")
    serializer_class = JobBookingSerializer
    permission_classes = [IsAuthenticated]
    lookup_field = "job_booking_id"

    def get_queryset(self):
        user = self.request.user
        qs = super().get_queryset()
        if hasattr(user, "employer"):
            return qs.filter(job__employer_id=user.employer.id)
        if hasattr(user, "cleaner"):
            return qs.filter(cleaner_id=user.cleaner.id)
        return qs.none()


# ---------------------------
# Service catalog  (CHANGED — NEW VIEWSET)
# ---------------------------

class ServiceViewSet(
    mixins.CreateModelMixin,           # <-- enables POST
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    viewsets.GenericViewSet,
):
    queryset = Service.objects.all().order_by("name")
    serializer_class = ServiceSerializer

    def get_permissions(self):
        # Only admins can create/update/delete; everyone can read
        if self.request.method in ("POST", "PUT", "PATCH", "DELETE"):
            return [IsAdminUser()]
        return [AllowAny()]


# ---------------------------
# Job <-> Service links  (CHANGED — NEW VIEWSET)
# ---------------------------

class JobServiceViewSet(
    viewsets.GenericViewSet,
    mixins.CreateModelMixin,
    mixins.DestroyModelMixin,
    mixins.ListModelMixin,
):  # <-- ADDED
    """
    Employers attach/detach services to their own job posts.

    POST body: { "job": <job_pk>, "service": <service_pk> }
    """
    queryset = JobService.objects.all().select_related("job", "service")
    serializer_class = JobServiceSerializer
    permission_classes = [IsAuthenticated]
    lookup_field = "job_service_id"

    def get_queryset(self):
        qs = super().get_queryset()
        user = self.request.user
        if hasattr(user, "employer"):
            return qs.filter(job__employer_id=user.employer.id)
        return qs.none()

    def perform_create(self, serializer):
        user = self.request.user
        if not hasattr(user, "employer"):
            raise PermissionError("Only employers can attach services to a job.")
        job = serializer.validated_data.get("job")
        if job.employer_id != user.employer.id:
            raise PermissionError("You can only attach services to your own job.")
        serializer.save()

    def destroy(self, request, *args, **kwargs):
        link = self.get_object()
        user = request.user
        if not hasattr(user, "employer") or link.job.employer_id != user.employer.id:
            return Response({"detail": "Only the job owner can remove services."}, status=403)
        return super().destroy(request, *args, **kwargs)


# ---------------------------
# Cleaner <-> Service links  (CHANGED — NEW VIEWSET)
# ---------------------------

class CleanerServiceViewSet(
    viewsets.GenericViewSet,
    mixins.CreateModelMixin,
    mixins.DestroyModelMixin,
    mixins.ListModelMixin,
):  # <-- ADDED
    """
    Cleaners manage their own service offerings.

    POST body: { "service": <service_pk> }
    Cleaner is injected from request.user.cleaner
    """
    queryset = CleanerService.objects.all().select_related("cleaner", "service")
    serializer_class = CleanerServiceSerializer
    permission_classes = [IsAuthenticated]
    lookup_field = "cleaner_service_id"

    def get_queryset(self):
        qs = super().get_queryset()
        user = self.request.user
        if hasattr(user, "cleaner"):
            return qs.filter(cleaner_id=user.cleaner.id)
        return qs.none()

    def perform_create(self, serializer):
        user = self.request.user
        if not hasattr(user, "cleaner"):
            raise PermissionError("Only cleaners can add services to their profile.")
        serializer.save(cleaner=user.cleaner)

    def destroy(self, request, *args, **kwargs):
        link = self.get_object()
        user = request.user
        if not hasattr(user, "cleaner") or link.cleaner_id != user.cleaner.id:
            return Response({"detail": "You can only remove services from your own profile."}, status=403)
        return super().destroy(request, *args, **kwargs)
